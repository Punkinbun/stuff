# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).
# ----------


# Perceptron implementation for imitation learning
import Helpers.util
from Exercises.perceptron_multiclass import PerceptronClassifier
from random import uniform
from pacman import GameState


class PerceptronClassifierPacman(PerceptronClassifier):
    def __init__(self, legalLabels, maxIterations):
        PerceptronClassifier.__init__(self, legalLabels, maxIterations)
        self.epochs = maxIterations
        self.weights = []
        self.moves = ['','']
        

    def convert_data(self, data):
        # fix datatype issues
        # if it comes in inside of a list, pull it out of the list
        if isinstance(data, list):
            data = data[0]

        #data comes as a tuple
        all_moves_features = data[0] #grab the features (dict of action->features)
        legal_moves = data[1]        #grab the list of legal moves from this state
        return_features = {}
        #loop each action
        for key in all_moves_features:
            #convert feature values from dict to list
            all_features = ['foodCount', 'STOP', 'nearest_ghost', 'ghost-0', 'capsule-0', 'food-0', 'food-1', \
                            'food-2', 'food-3', 'food-4', 'capsule count', 'win', 'lose', 'score']
            dict_features = all_moves_features[key] 
            list_features = []
            # grab all feature values & put them in a list
            for feat in all_features:
                if feat not in dict_features:
                    list_features.append(0)
                else:
                    list_features.append(dict_features[feat])
            return_features[key] = list_features

        return (return_features, legal_moves) 


    def classify(self, data):
        #leave this call to convert_data here!
        features, legal_moves = self.convert_data(data)

        ##your code goes here##
        
        predictions = {'North':-1000000000000, 'South':-1000000000000, 'West':-1000000000000, 'East':-1000000000000, 'Stop':-1000000000000}
        for x in legal_moves:
            sum = 0
            pos = 0
            features[x].append(1)
            for n in features[x]:
                if n == True:
                    n = 1
                if n == False:
                    n = 0
                sum += n * self.weights[pos]
                pos += 1
            
            predictions[x] = sum
        large = ''
        large_num = -1000000000000
        
        for x in legal_moves:
            if predictions[x] > large_num:
                large = x
                large_num = predictions[x]
        
        #your predicted_label needs to be returned inside of a list for the PacMan game
        predicted_label = large
        return [predicted_label] 

    def train(self, train_data, labels):
        for x in range(15):
            self.weights.append(uniform(-1,1))
        
        for i in range(self.epochs):
            num_correct = 0
            for x in train_data:
                features, legal_moves = self.convert_data(x)
                predicted = self.classify(x)[0]
                features, legal_moves = self.convert_data(x)
                for n in legal_moves:
                    features[n].append(1)
                    if features[n][11]:
                        features[n][11] = 1
                    else: 
                        features[n][11] = 0

                    if features[n][12]:
                        features[n][12] = 1
                    else: 
                        features[n][12] = 0
                correct = labels[train_data.index(x)]
                if predicted == correct:
                    num_correct += 1
                    continue
                else:
                    self.adjust_weights(correct, predicted, 1, features)

            print("Epoch " + str(i) + " Accuracy: " + str((num_correct/len(train_data))*100))

    def adjust_weights(self, correct, incorrect, l_rate, features):
        for i in range(len(self.weights)):
            self.weights[i] += l_rate * (1 * features[correct][i])
            self.weights[i] += l_rate * (-1 * features[incorrect][i])
        