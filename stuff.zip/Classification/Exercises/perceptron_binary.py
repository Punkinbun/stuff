from random import uniform

# Make a prediction with weights
def classify(row, weights):
    #print(row[-1])
    sum = 0
    for i in range(len(row)):
        sum += row[i]*weights[i]
    if sum >= 0:
        return 1
    else:
        return 0 

        
 
#Estimate Perceptron weights using stochastic gradient descent
def train(train_data, n_epoch, l_rate=1):
    weights = []
    for i in range(61):
        weights.append(uniform(-1,1))
    
    for a in range(n_epoch):
        num_correct = 0
        
        for j in range(len(train_data)):
            temp = []
            for i in range (len(train_data[j])):
                temp.append(train_data[j][i])
            clas = temp.pop(-1)
            temp.append(1)
            output = classify(temp, weights)
            
            if (output == clas):
                num_correct += 1
                continue
            else:
                if (output > clas):
                    weights = adjust_weights(-1,weights,l_rate,temp)
                else:
                    weights = adjust_weights(1,weights,l_rate,temp)
        print(f"Epoch {a} Accuracy: " + str((num_correct/208)*100))
        cross_validate(train_data, 5, 1)
    #Test Cases
    #print(train_data[128][-1])
    #train_data[128].pop(-1)
    #train_data[128].append(1)
    #print(classify(train_data[128], weights))
    

def adjust_weights(error,weights,l_rate,row):
    temp = []
    for i in range(len(weights)):
        temp.append(weights[i] + l_rate*(error*row[i]))
    return temp

def cross_validate(data, n_folds, n_epoch):
    print(data)
    temp_list_1 = []
    temp_list_2 = data.copy()
    train_sets = []
    validate_sets = []
    
    for i in range(n_folds):
        for a in range(i * n_folds, round(len(data[i]) / n_folds)):
            temp_list_1.append(data[i])
    print(len(temp_list_1))


        
        


