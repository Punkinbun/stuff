from random import uniform

# Make a prediction with weights
def classify(row, weights):
    #print(row[-1])
    sum = 0
    for i in range(len(row)):
        sum += row[i]*weights[i]
    if sum >= 0:
        return 1
    else:
        return 0 

        
 
#Estimate Perceptron weights using stochastic gradient descent
def train(train_data, n_epoch, l_rate=1):
    weights = []
    for i in range(61):
        weights.append(uniform(-1,1))
    
    for i in range(n_epoch):
        num_correct = 0
        
        for j in range(len(train_data)):
            temp = []
            for i in range (len(train_data[j])):
                temp.append(train_data[j][i])
            clas = temp.pop(-1)
            temp.append(1)
            output = classify(temp, weights)
            
            if (output == clas):
                num_correct += 1
                continue
            else:
                if (output > clas):
                    weights = adjust_weights(-1,weights,l_rate,temp)
                else:
                    weights = adjust_weights(1,weights,l_rate,temp)
        print("Epoch " + str(i) + " Accuracy: " + str((num_correct/208)*100))
    
    #Test Cases
    #print(train_data[128][-1])
    #train_data[128].pop(-1)
    #train_data[128].append(1)
    #print(classify(train_data[128], weights))
    

def adjust_weights(error,weights,l_rate,row):
    temp = []
    for i in range(len(weights)):
        temp.append(weights[i] + l_rate*(error*row[i]))
    return temp
        
        


