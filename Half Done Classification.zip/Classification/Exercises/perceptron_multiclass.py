# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).
# ----------


# Perceptron implementation
import Helpers.util
from random import uniform


class PerceptronClassifier:

    def __init__( self, legalLabels, max_iterations):
        self.legalLabels = legalLabels
        self.type = "perceptron"
        self.epochs = max_iterations
        self.weights = [[]]

    def classify(self, data):
        predictions = []
        
        for a in range(len(self.legalLabels) - 1):
            sum = 0
            for i in range(len(data) - 1):
                sum += data[i]*self.weights[a][i]
            predictions.append(sum)
        
        return(predictions.index(max(predictions)))
    

    def train(self, train_data, labels):
        for c in range(9):
            self.weights.append([])

        print(len(self.weights))
        for b in range(10):
            for a in range(len(train_data[0])):
                self.weights[b].append(uniform(-1,1))
        
        for i in range(self.epochs):
            
            num_correct = 0
            for j in range(len(train_data)):
                
                temp = []
                for n in range (len(train_data[j])):
                    temp.append(train_data[j][n])
                temp.append(1)
                
                output = self.classify(temp)
                
                if (output == labels[j]):
                    num_correct += 1
                    continue
                else:
                    
                    self.adjust_weights(labels[j],output,1,train_data[j])
                    

            print("Epoch " + str(i) + " Accuracy: " + str((num_correct/len(train_data))*100))
    
    def adjust_weights(self,correct,incorrect,l_rate,row):
        print(self.weights[correct][0])
        for i in range(len(self.weights)-1):
            
            c_weight = self.weights[correct][i] + l_rate*(1*row[i])
            ic_weight = self.weights[incorrect][i] + l_rate*(-1*row[i])

            self.weights[correct].pop(i)
            self.weights[incorrect].pop(i)

            self.weights[correct].insert(i, c_weight)
            self.weights[incorrect].insert(i, ic_weight)
            



        
        

